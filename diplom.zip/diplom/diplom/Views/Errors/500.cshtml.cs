using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace diplom.Views.Errors
{
    public class _500Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
