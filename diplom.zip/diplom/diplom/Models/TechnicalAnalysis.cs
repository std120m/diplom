﻿using Microsoft.ML;
using static Diplom.MLModel;

namespace diplom.Models
{
    public static class TechnicalAnalysis
    {
        public static double GetPrediction(Share share)
        {
            MLContext mlContext = new MLContext();
            ITransformer mlModel = mlContext.Model.Load("MLModel.zip", out var modelInputSchema);
            var predEngine = mlContext.Model.CreatePredictionEngine<ModelInput, ModelOutput>(mlModel);

            var input = new ModelInput(share);
            ModelOutput result = predEngine.Predict(input);

            return result.Score;
        }


    }
}
